def my_handler(event, context):
   return "Hello World"

